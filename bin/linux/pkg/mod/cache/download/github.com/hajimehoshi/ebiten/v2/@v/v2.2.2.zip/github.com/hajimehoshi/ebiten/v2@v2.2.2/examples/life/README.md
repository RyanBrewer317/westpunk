# Conway's Game of Life

The original project is [martinlindhe/gol](https://github.com/martinlindhe/gol) by Martin Lindhe.

## License

MIT
