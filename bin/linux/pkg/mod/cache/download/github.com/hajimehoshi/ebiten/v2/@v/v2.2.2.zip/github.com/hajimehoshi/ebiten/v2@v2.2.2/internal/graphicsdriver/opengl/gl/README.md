This is a fork of `github.com/go-gl/gl/v2.1/gl` with the below patch. This is now modified manually.

The original version is generated from `github.com/hajimehoshi/glow`'s `nocgo` branch. This enables to remove dependencies on Cgo on Windows.

Now we are working on commiting this 'no-cgo' change to the official gl package. See https://github.com/go-gl/glow/pull/102.
