package main

func Foo(x vec2) vec2 {
	return Bar(x)
}

func Bar(x vec2) vec2 {
	return x
}
