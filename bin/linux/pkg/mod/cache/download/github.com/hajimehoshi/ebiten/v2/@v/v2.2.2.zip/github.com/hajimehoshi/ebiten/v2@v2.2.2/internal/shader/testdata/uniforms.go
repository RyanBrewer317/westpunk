package main

var (
	Foo vec2
	Boo vec4
)
