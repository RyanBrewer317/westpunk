#include <stdint.h>

typedef uint32_t my_uint;

int main() {
    return 0;
}
