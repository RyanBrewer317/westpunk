#define foo2(a, b...) bar2(a, b)
foo2(1, 2, 3);
