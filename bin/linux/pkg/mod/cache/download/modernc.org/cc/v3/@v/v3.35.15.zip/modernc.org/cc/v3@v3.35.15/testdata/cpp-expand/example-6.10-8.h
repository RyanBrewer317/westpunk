#define EMPTY
EMPTY # include <file.h>
