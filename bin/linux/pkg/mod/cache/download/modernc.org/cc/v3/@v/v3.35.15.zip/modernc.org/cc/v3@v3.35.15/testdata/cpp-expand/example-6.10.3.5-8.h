#define OBJ_LIKE (1-1)
#define OBJ_LIKE /* white space */ (1-1) /* other */
#define FUNC_LIKE(a) ( a )
#define FUNC_LIKE( a ) ( /* note the white space */ \
		a /* other stuff on this line
		*/ )
ok
