#define OBJ_LIKE (1-1)
#define OBJ_LIKE (0) // different token sequence
