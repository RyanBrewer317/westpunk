int
foo (double x, long double y)
{
  return __builtin_isgreater (x, y);
}
