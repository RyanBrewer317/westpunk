ubidi_writeReordered_49( int *dest, const unsigned char *dirProps) 
{
    if (!(1&(1UL<<*dirProps)))
      *dest=1;
}
