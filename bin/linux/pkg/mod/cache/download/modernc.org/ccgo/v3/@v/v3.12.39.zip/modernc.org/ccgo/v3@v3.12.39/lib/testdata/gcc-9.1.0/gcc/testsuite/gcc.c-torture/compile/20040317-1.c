int String2Array(int len, char strarr[][len])
{
  strarr[0];
}
