# httpfs

Package httpfs implements http.FileSystem on top of a map[string]string.

Installation

    $ go get [-u] modernc.org/httpfs

Documentation: [godoc.org/modernc.org/httpfs](http://godoc.org/modernc.org/httpfs)
