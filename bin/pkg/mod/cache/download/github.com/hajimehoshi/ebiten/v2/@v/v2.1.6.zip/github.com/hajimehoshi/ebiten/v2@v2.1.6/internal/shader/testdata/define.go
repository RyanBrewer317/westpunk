package main

func Foo(foo vec2) vec4 {
	r := vec4(foo, 0, 1)
	return r
}
