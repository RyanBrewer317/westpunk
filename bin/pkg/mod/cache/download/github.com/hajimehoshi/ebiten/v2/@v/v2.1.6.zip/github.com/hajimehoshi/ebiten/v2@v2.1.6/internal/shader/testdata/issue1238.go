package main

func Vertex(position vec2) vec4 {
	if true {
		return vec4(position, 0, 1)
	}
	return vec4(position, 0, 1)
}

func Fragment(position vec4) vec4 {
	if true {
		return position
	}
	return position
}
