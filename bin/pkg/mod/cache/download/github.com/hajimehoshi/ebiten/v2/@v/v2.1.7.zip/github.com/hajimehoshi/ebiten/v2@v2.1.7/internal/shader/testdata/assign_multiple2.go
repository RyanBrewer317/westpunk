package main

func Foo() vec2 {
	r1, r2 := 1.0, 2.0
	return vec2(r1, r2)
}
