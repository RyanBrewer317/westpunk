package main

const a = 1
const b = 2 + 0.5

func Foo() vec2 {
	return vec2(a + b)
}
