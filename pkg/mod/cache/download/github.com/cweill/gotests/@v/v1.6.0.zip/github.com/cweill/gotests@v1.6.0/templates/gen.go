//go:generate esc -include=.*\.tmpl -o=tmpl.go -pkg=templates ./
package templates
