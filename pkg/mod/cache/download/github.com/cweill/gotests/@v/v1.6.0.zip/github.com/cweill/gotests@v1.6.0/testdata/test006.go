package testdata

func Foo6(i int, b bool) (string, error) { return "", nil }
