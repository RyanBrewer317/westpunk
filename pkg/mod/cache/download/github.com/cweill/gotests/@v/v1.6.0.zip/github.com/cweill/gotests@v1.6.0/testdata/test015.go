package testdata

func Foo15(f func(string) (string, error)) error { return nil }
