package testdata

func Foo19(in1, in2, in3 string) string { return "" }
