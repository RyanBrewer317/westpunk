package testdata

func Foo25(interface{}) (string, []byte, error) {
	return "", nil, nil
}
