package testdata

func Foo101(s string) string {
	return ""
}
