package testdata

func Foo201a() bool { return false }

func Foo201b() error { return nil }

func Foo201c(n int) error { return nil }

func Foo201d() (bool, error) { return false, nil }

func Foo201e(n int, s string) (bool, error) { return false, nil }
