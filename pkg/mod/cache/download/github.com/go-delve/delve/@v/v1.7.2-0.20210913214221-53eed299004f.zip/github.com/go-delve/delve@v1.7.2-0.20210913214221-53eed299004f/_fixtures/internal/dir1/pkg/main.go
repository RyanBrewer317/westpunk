package pkg

var A = 1

type SomeType struct {
	X int
	Y int
}
