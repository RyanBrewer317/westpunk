package glfw

/*
#cgo CFLAGS: -x objective-c
#ifdef _GLFW_COCOA
	#include "glfw/src/cocoa_monitor.m"
#endif
*/
import "C"
