#ifdef _GLFW_WAYLAND
	#include "glfw/src/wl_monitor.c"
#endif

