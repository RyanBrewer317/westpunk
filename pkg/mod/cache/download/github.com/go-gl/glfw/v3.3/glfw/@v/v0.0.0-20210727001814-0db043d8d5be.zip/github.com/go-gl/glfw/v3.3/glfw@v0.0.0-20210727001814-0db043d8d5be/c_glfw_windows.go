package glfw

/*
#include "glfw/src/win32_init.c"
#include "glfw/src/win32_joystick.c"
#include "glfw/src/win32_monitor.c"
#include "glfw/src/win32_time.c"
#include "glfw/src/win32_thread.c"
#include "glfw/src/win32_window.c"
#include "glfw/src/wgl_context.c"
#include "glfw/src/egl_context.c"
*/
import "C"
