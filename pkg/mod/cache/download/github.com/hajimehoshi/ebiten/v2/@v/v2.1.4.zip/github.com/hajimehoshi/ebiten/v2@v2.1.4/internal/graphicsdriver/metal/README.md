These packages are copied from Dmitri Shuralyov's mtl packages and edited with Dmitri's permission:

* `github.com/hajimehoshi/ebiten/v2/internal/graphicsdriver/metal/ca` (copied from `dmitri.shuralyov.com/gpu/mtl/example/movingtriangle/internal/ca`)
* `github.com/hajimehoshi/ebiten/v2/internal/graphicsdriver/metal/mtl` (copied from `dmitri.shuralyov.com/gpu/mtl`)
* `github.com/hajimehoshi/ebiten/v2/internal/graphicsdriver/metal/ns` (copied from `dmitri.shuralyov.com/gpu/mtl/example/movingtriangle/internal/ns`)
