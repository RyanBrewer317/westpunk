package main

func Foo(f float) int {
	x := int(f)
	return x
}
