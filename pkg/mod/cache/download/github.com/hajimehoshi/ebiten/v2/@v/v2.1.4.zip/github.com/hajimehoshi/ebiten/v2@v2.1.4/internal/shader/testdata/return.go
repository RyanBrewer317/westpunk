package main

func Foo(a vec2) (b vec3, c vec4) {
	b = vec3(1)
	return
}
