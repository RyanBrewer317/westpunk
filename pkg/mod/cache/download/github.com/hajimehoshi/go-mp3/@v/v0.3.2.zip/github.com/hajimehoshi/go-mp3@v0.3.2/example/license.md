# classic.mp3

Licensed under the EFF OAL License

http://freemusicarchive.org/music/Advent_Chamber_Orchestra/Selections_from_the_2005-2006_Season/Advent_Chamber_Orchestra_-_04_-_Mozart_-_A_Little_Night_Music_allegro

# mpeg2.mp3

This audio file contains speech synthesized parts of Alice's Adventures in Wonderland by Lewis Carroll, published in 1865. Due to the release date this work is under public domain.